./node_modules/.bin/mocha --recursive -r test/test-helper.js "$@"
